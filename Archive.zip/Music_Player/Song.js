let currentSong;

let Song = function (data, parent) {
  let playing = false;
  let main = this;

  // functions
  let SecondsToTime = function (seconds) {
    seconds = Math.round(seconds);

    let minutes = Math.floor(seconds / 60);
    seconds = seconds % 60;

    return { minutes: minutes, seconds: seconds };
  };

  function getTimeFormatted(seconds) {
    let currentTime = SecondsToTime(seconds);
    let minutes = currentTime.minutes;
    let new_seconds = currentTime.seconds;

    if (new_seconds < 10 && new_seconds > 0) new_seconds = "0" + new_seconds;
    else if (new_seconds == 0) new_seconds = "00";

    let formattedTime = minutes + ":" + new_seconds;

    return formattedTime;
  }

  // frame
  let frame = document.createElement("div");
  frame.className = "music-song";

  // song title
  let songTitle = document.createElement("p");
  songTitle.className = "music-song-title";
  songTitle.innerHTML = data.title;

  // song author
  let songAuthor = document.createElement("span");
  songAuthor.className = "music-song-author";
  songAuthor.innerHTML = "By " + data.author;

  //  horizontal line
  let hr = document.createElement("hr");

  // play button
  let buttonPlay = document.createElement("button");
  buttonPlay.className = "music-play-button";
  buttonPlay.innerHTML = "Play";

  // input slider
  let inputSlider = document.createElement("input");
  inputSlider.type = "range";
  inputSlider.max = "100";
  inputSlider.value = "0";
  inputSlider.className = "music-volume-slider";

  let slider_selected = false;

  inputSlider.addEventListener("input", function () {
    slider_selected = true;

    let percentOffset = inputSlider.value / 100;

    currentTimeElement.innerHTML = getTimeFormatted(
      audio.duration * percentOffset
    );
  });
  inputSlider.addEventListener("change", function () {
    let percentOffset = inputSlider.value / 100;
    let time = audio.duration * percentOffset;
    audio.currentTime = time;

    slider_selected = false;

    if (audio.currentTime == audio.duration) main.pauseAudio();
    else main.playAudio();
  });

  // current time
  let currentTimeElement = document.createElement("span");
  currentTimeElement.className = "music-song-time";
  currentTimeElement.innerHTML = "0:00";

  function updateCurrentTime() {
    let formattedTime = getTimeFormatted(audio.currentTime);

    if (currentTimeElement.innerHTML !== formattedTime) {
      currentTimeElement.innerHTML = formattedTime;
      if (slider_selected == false)
        inputSlider.value = (audio.currentTime / audio.duration) * 100;
    }

    if (playing == false) return;
    if (slider_selected == true) return;
    setTimeout(updateCurrentTime, 100);
  }

  // audio

  let audio = new Audio(data.path);
  audio.preload = "metadata";
  this.audio = audio;

  this.pauseAudio = function () {
    playing = false;
    audio.pause();
    buttonPlay.innerHTML = "Play";
    buttonPlay.className = "music-play-button";
  };

  this.playAudio = function () {
    if (currentSong !== undefined) {
      currentSong.pauseAudio();
    }
    playing = true;

    currentSong = main;
    if (audio.currentTime == audio.duration) audio.currentTime = 0;
    audio.play();
    updateCurrentTime();
    buttonPlay.innerHTML = "Pause";
    buttonPlay.className = "music-pause-button";
  };
  this.toggleAudio = function () {
    if (playing) {
      main.pauseAudio();
    } else {
      main.playAudio();
    }
  };

  audio.onended = function(){
    main.pauseAudio()
  }
  
  buttonPlay.addEventListener("click", this.toggleAudio);

  // max time
  let maxTime = document.createElement("span");
  maxTime.className = "music-song-time";

  audio.onloadedmetadata = function () {
    let formattedTime = getTimeFormatted(audio.duration);
    maxTime.innerHTML = formattedTime;
  };

  // end

  parent.appendChild(frame);
  frame.appendChild(songTitle);
  songTitle.appendChild(songAuthor);
  frame.appendChild(hr);
  frame.appendChild(buttonPlay);
  frame.appendChild(currentTimeElement);

  frame.appendChild(inputSlider);

  frame.appendChild(maxTime);

  this.Frame = frame;
};
export default Song


