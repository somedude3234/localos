import Song from "./Song.js"

let DIL_Pt2 = {
    author: "YNW Melly",
        title: "Dangerously In Love Part 2",
        path: "music/DIL_Pt2.mp3"
}
let Bags = {
    author: "Kevin Gates",
    title: "Bags",
    path:"music/Bags.mp3"
}
let Trap_Queen = {
    author: "Fetty Wap",
    title: "Trap Queen",
    path: "music/Trap Queen.mp3"
}
let Great_Man = {
    author: "Kevin Gates",
    title: "Great Man",
    path: "music/Great Man.mp3"
}

 for (let i = 1; i <= 1; i++) {
    new Song(DIL_Pt2,document.body);
    new Song(Bags, document.body)
    new Song(Trap_Queen, document.body)
    new Song(Great_Man, document.body)
  }

